<!DOCTYPE html>
<html>
<head>
	<title>Register here</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style type="text/css">
		label.error{
			color:red;
			padding:5px;
			background-color: yellow;
			margin-left:10px;
		}
		#loader{
			display: none;
		}
	</style>
</head>
<body>
	<div class="container-fluid">
<form method="post" id="regfrm" enctype="multipart/form-data">
	<input type="hidden" name="tab" value="register">
	<table>
		<tr>
			<td>
				Name
			</td>
			<td>
				<input type="text" name="name" id="name" minlength="3" required>
			</td>
		</tr>
		<tr>
			<td>
				Email
			</td>
			<td>
				<input type="email" name="email" id="email" required>
			</td>
		</tr>
		<tr>
			<td>
				Password
			</td>
			<td>
				<input type="password" name="password" id="password" required>
			</td>
		</tr>
		<tr>
			<td>
				Profile Pic
			</td>
			<td>
				<input type="file" name="image" id='file' required>
			</td>
		</tr>
		<tr>
			<td>
				Music
			</td>
			<td>
				<input type="file" name="music" id='music' required>
			</td>
		</tr>
		<tr>
			<td>
				Video
			</td>
			<td>
				<input type="file" name="video" id='video' required>
			</td>
		</tr>
		<tr>
			<td>
				<input type="submit" name="okay" value="Sign Up" id="submitbtn" class="btn btn-primary">
			</td>
		</tr>
	</table>
</form>
<span id="loader"><i class="fa fa-spinner fa-spin fa-3x"></i> processing..please wait..</span>
<div class="col-md-6" id="msg"></div>
	<hr>
	<div id="viewData"></div>
</div>
<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/validate.js"></script>
	<script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
	<script type="text/javascript">
		$(document).ready(function(){

			$("#viewData").load("view.php");

			$("#submitbtn").click(function(){

				$("#regfrm").validate({

					submitHandler:function(){
						var formData = new FormData();
						formData.append('image', $('#file')[0].files[0]);
						formData.append('music', $('#music')[0].files[0]);
						formData.append('video', $('#video')[0].files[0]);


						var name = $("#name").val();
						var email = $("#email").val();
						var password = $("#password").val();
						formData.append('name',name);
						formData.append('email',email);
						formData.append('password',password);
						formData.append('tab','register');
						$.ajax({
							url:"process.php",
							type:"POST",
							processData: false,
       						contentType: false,
							data:formData,
							beforeSend:function(response){
								$("#loader").fadeIn(1000);
							},
							error:function(response){
								$("#loader").fadeOut(1000);
								console.log(response.status);

							},
							success:function(response){
								if(response==1){

									$("#msg").fadeIn(1000);
									$("#regfrm")[0].reset();
									$("#loader").fadeOut(1000);	
									$("#msg").removeClass('alert alert-danger');
									$("#msg").addClass('alert alert-success').html("Data saved successfully");
									setTimeout(function(){
										$("#msg").fadeOut(1000);
									},4000);
									$("#viewData").load("view.php");
								} else {
									$("#msg").fadeIn(1000);
									$("#loader").fadeOut(1000);	
									$("#msg").removeClass('alert alert-success');
									$("#msg").addClass('alert alert-danger').html(response);
									setTimeout(function(){
										$("#msg").fadeOut(1000);
									},4000);
								}

							}
						})
					}
				});
			});
		});



	</script>
	
</body>
</html>