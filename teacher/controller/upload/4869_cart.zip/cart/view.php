
<?php
$conn = mysqli_connect("localhost","root","","gim_ecom") or die(mysqli_error($conn)); 
$dataObject = mysqli_query($conn,"SELECT * FROM products") or die(mysqli_error($conn));
$count = 0;
if(mysqli_num_rows($dataObject)==0){
	echo 0;
} else {
	?>
	<a id="cart_btn" class="btn btn-success">Cart</a>
	<span id="cart"></span>
	<table class="table table-responsive">
			<thead>
			<tr>
				<th>
					Name
				</th>
				<th>
					Description
				</th>
				<th>
					Price
				</th>
				<th>
					Quantity
				</th>
				<th>
					Code
				</th>
				<th>
					Photo
				</th>
				
			</tr>
		</thead>
		<tbody>
		<?php
		while($row=mysqli_fetch_array($dataObject)) {
		?><tr>
		<td class="ce" onBlur="edit(this,'name','<?php echo $row['id']?>')"><?php echo $row['product_name']?></td>
		<td class="ce" onBlur="edit(this,'email','<?php echo $row['id']?>')"><?php echo $row['description']?></td>
		<td class="ce" onBlur="edit(this,'email','<?php echo $row['id']?>')"><?php echo $row['price']?></td>
		<td class="ce" onBlur="edit(this,'email','<?php echo $row['id']?>')"><?php echo $row['quantity']?></td>
		<td class="ce" onBlur="edit(this,'email','<?php echo $row['id']?>')"><?php echo $row['product_code']?></td>
		
		<td><a href="<?php echo $row['url']?>" target="_blank"><img src="<?php echo $row['img']?>" width="100" height="95"></a></td>
		<td><a href="#" onclick="delete1('<?php echo $row['product_code']?>')">ADD CART</a></td>
	</tr>
		<?php
	}
?></tbody></table><?php

}
?>
<script type="text/javascript">
	function edit(Obj,column,id){
		var value = Obj.innerHTML;
		if(value=="") return;
		$.ajax({
			url:"editable.php",
			data:{column:column,value:value,id:id},
			type:"POST",
			success:function(r){
				if(r==1) {
					$(Obj).css('background-color','green');
					setTimeout(function(){
						$(Obj).css('background-color','white');
					},2000);
				} else {
					console.log(r);
				}
			}
		})
	}




	$("#enableedit").click(function(){
		var val = $(this).html();
		if(val=="Edit"){
			$(".ce").prop('contenteditable',true);
			$(".ce").css('background-color','lightgreen');
			$(this).html('Finish?');
		} else {
			$(this).html('Edit');
			$(".ce").prop('contenteditable',false);
			$(".ce").css('background-color','white');

		}
	})
</script>
<script type="text/javascript">
	function delete1(product_code) {
		// body...
		// console.log(id);
		$.ajax({
							url:"delete.php",
							type:"GET",
							data:{product_code:product_code},
							 // {name:name,email:email,password:password,btn:btn}
							
							success:function(response){
								if(response==1){

									$("#msg").fadeIn(1000);
									$("#regfrm")[0].reset();
									$("#loader").fadeOut(1000);	
									/*$("#cart_btn").css('background-color','white');*/
									$("#msg").removeClass('alert alert-danger');
									$("#msg").addClass('alert alert-success').html("Product Added successfully");
									setTimeout(function(){
										$("#msg").fadeOut(1000);
									},4000);
									
									$("#viewData").load("view.php");
								} else {
									$("#msg").fadeIn(1000);
									$("#loader").fadeOut(1000);	
									$("#msg").removeClass('alert alert-success');
									$("#msg").addClass('alert alert-danger').html(response);
									setTimeout(function(){
										$("#msg").fadeOut(1000);
									},4000);
								}

							}
						})
	
				

	}
</script>
