<?php
$conn = mysqli_connect("localhost","root","","gim_ecom") or die(mysqli_error($conn)); 
$product_code = $_GET['product_code'];
$qry = "SELECT * FROM products WHERE product_code ='$product_code'";
$exec = mysqli_query($conn,$qry) or die(mysqli_error($conn));

//echo"<h1>$product_code</h1>";
echo "1";

/*session_start();
$status="";
if (isset($_POST['action']) && $_POST['action']=="remove"){
if(!empty($_SESSION["shopping_cart"])) {
	foreach($_SESSION["shopping_cart"] as $key => $value) {
		if($_POST["code"] == $key){
		unset($_SESSION["shopping_cart"][$key]);
		$status = "<div class='box' style='color:red;'>
		Product is removed from your cart!</div>";
		}
		if(empty($_SESSION["shopping_cart"]))
		unset($_SESSION["shopping_cart"]);
			}		
		}
	}

if (isset($_POST['action']) && $_POST['action']=="change"){
  foreach($_SESSION["shopping_cart"] as &$value){
    if($value['code'] === $_POST["code"]){
        $value['quantity'] = $_POST["quantity"];
        break; // Stop the loop after we've found the product
    }
}
  	
}*/
?>